# Angular 7 boilerplate

This Angular 7 boilerplate contains:

- Angular Material
- Flex Layout
- Auth module with sign-up and login forms
