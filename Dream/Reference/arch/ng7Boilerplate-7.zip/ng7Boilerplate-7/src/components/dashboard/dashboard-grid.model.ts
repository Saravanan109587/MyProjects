export class DashboardGridModel {
    Bordereaus: string[];
    ColDef: any[];
}
