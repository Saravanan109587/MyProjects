export class FileInfoModel {
    FileId: string;
    FileName: string;
    SheetName: string;
    SheetNames: string[];
    FilePath: string;
}
