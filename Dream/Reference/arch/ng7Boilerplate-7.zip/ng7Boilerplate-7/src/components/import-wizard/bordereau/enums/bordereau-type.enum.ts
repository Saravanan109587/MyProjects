export enum BordereauType {
    Policy,
    Exposure
}
