export enum BordereauFrequency {
    Annual,
    Quarterly,
    SemiAnnual
}
