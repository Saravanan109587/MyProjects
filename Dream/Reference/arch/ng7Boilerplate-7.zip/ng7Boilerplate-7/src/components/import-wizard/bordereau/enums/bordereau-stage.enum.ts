export enum BordereauStage {
    PendingFileUpload,
    PendingMapping,
    PendingValidation,
    PendingNameMatch,
    NameMatchInProgress,
    NameMatchComplete
}
