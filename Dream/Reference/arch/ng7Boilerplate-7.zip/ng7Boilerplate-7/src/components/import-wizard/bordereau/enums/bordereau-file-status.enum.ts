export enum BordereauFileStatus {
    FullyReceived,
    PartiallyReceived
}
