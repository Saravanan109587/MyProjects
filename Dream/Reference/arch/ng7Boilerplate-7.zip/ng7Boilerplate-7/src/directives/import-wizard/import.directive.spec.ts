import { ImportDirective } from './import.directive';

describe('ImportDirective', () => {
  it('should create an instance', () => {
    const directive = new ImportDirective();
    expect(directive).toBeTruthy();
  });
});
