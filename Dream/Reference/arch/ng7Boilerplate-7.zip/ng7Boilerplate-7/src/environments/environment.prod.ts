export const environment = {
    production: true,
    appRoot: ''
};
