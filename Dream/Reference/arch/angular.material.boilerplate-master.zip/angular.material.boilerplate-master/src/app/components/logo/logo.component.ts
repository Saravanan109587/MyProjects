import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-logo',
	templateUrl: './logo.component.html',
	styleUrls: []
})
export class LogoComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
