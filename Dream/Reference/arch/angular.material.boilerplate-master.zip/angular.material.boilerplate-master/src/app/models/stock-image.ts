export interface StockImage {
	stockImageId: string;
	name: string;
	image: string;
}
