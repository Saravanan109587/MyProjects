export interface StockAccessory {
	stockAccessoryId: string;
	name: string;
	description: string;
}
