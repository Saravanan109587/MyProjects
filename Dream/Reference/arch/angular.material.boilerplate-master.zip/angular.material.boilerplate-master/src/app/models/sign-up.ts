export interface SignUp {
	username: string;
	password: string;
	emailAddress: string;
}
