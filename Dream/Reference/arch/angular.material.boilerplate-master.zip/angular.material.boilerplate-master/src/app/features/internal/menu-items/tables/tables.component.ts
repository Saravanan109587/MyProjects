import { Component } from '@angular/core';

@Component({
	selector: 'app-tables',
	styles: [],
	template: `<router-outlet></router-outlet>`
})
export class TablesComponent {}
