import { Component, Input } from '@angular/core';

@Component({
	selector: 'app-sidenav-menu',
	styles: [],
	templateUrl: './sidenav-menu.component.html'
})
export class SidenavMenuComponent {}
