import { Component } from '@angular/core';
import { AppConfig } from '@app/config';

@Component({
	selector: 'app-demo-search-overlay',
	styles: [],
	templateUrl: './search-overlay.component.html'
})
export class SearchOverlayComponent {}
