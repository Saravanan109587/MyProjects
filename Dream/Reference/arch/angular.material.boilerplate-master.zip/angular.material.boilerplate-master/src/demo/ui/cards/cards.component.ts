import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-cards',
	styles: [],
	templateUrl: './cards.component.html'
})
export class UICardsComponent {}
