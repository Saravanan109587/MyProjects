import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-timeline',
	styles: [],
	templateUrl: './timeline.component.html'
})
export class UITimelineComponent {}
