import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-color',
	styles: [],
	templateUrl: './color.component.html'
})
export class UIColorComponent {}
