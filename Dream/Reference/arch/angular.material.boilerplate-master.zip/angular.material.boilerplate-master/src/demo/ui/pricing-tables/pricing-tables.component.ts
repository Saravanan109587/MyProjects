import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-pricing-tables',
	styles: [],
	templateUrl: './pricing-tables.component.html'
})
export class UIPricingTablesComponent {}
