import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-hover',
	styles: [],
	templateUrl: './hover.component.html'
})
export class UIHoverComponent {}
