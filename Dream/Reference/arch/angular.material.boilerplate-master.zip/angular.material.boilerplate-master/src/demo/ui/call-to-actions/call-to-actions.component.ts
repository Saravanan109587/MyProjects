import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-call-to-actions',
	styles: [],
	templateUrl: './call-to-actions.component.html'
})
export class UICallToActionsComponent {}
