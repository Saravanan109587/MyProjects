import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-buttons',
	styles: [],
	templateUrl: './buttons.component.html'
})
export class UIButtonsComponent {}
