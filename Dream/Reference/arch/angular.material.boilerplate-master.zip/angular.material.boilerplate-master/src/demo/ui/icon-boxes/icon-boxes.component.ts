import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-icon-boxes',
	styles: [],
	templateUrl: './icon-boxes.component.html'
})
export class UIIconBoxesComponent {}
