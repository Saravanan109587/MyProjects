import { Component } from '@angular/core';

// openDialog
@Component({
	selector: 'app-dialog-overview-example-dialog',
	template: `<p> Hi, I'm a simple dialog! </p>`
})
export class DialogOverviewExampleDialogComponent {}
