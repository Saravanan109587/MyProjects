import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-grids',
	styles: [],
	templateUrl: './grids.component.html'
})
export class UIGridsComponent {}
