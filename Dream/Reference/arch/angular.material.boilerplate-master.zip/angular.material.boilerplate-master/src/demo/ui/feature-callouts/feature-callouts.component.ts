import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-feature-callouts',
	styles: [],
	templateUrl: './feature-callouts.component.html'
})
export class UIFeatureCalloutsComponent {}
