import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-boxes',
	styles: [],
	templateUrl: './boxes.component.html'
})
export class UIBoxesComponent {}
