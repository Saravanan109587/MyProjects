import { Component } from '@angular/core';

@Component({
	selector: 'app-ui-icons',
	styles: [],
	templateUrl: './icons.component.html'
})
export class UIIconsComponent {}
