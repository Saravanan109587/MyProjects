import { Component } from '@angular/core';

@Component({
	selector: 'app-page-services',
	styles: [],
	templateUrl: './services.component.html'
})
export class PageServicesComponent {}
