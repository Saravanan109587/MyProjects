import { Component } from '@angular/core';

@Component({
	selector: 'app-page-faqs',
	styles: [],
	templateUrl: './faqs.component.html'
})
export class PageFaqsComponent {}
