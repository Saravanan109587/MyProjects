import { Component } from '@angular/core';

@Component({
	selector: 'app-page-about',
	styles: [],
	templateUrl: './about.component.html'
})
export class PageAboutComponent {}
