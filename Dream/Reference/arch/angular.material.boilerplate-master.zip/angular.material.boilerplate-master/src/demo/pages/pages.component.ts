import { Component } from '@angular/core';

@Component({
	selector: 'app-pages',
	styles: [],
	template: `<router-outlet></router-outlet>`
})
export class PagesComponent {}
