import { Component } from '@angular/core';

@Component({
	selector: 'app-page-terms',
	styles: [],
	templateUrl: './terms.component.html'
})
export class PageTermsComponent {}
