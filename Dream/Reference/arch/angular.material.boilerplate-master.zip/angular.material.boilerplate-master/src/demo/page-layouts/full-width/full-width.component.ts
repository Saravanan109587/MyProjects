import { Component } from '@angular/core';

@Component({
	selector: 'app-page-layout-full-width',
	styles: [],
	templateUrl: './full-width.component.html'
})
export class PageLayoutFullWidthComponent {}
