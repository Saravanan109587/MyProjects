import { Component } from '@angular/core';

@Component({
	selector: 'app-page-layout-centered',
	styles: [],
	templateUrl: './centered.component.html'
})
export class PageLayoutCenteredComponent {}
