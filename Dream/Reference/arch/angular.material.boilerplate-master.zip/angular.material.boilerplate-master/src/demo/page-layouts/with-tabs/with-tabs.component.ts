import { Component } from '@angular/core';

@Component({
	selector: 'app-page-layout-with-tabs',
	styles: [],
	templateUrl: './with-tabs.component.html'
})
export class PageLayoutWidthTabsComponent {}
