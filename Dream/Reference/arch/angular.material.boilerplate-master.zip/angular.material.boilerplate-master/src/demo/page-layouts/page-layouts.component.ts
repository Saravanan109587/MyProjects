import { Component } from '@angular/core';

@Component({
	selector: 'app-page-layouts',
	styles: [],
	template: `<router-outlet></router-outlet>`
})
export class PageLayoutsComponent {}
