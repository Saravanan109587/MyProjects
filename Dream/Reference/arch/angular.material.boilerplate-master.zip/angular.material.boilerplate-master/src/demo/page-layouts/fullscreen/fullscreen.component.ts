import { Component } from '@angular/core';

// Children of AppModule instead of AppMainModule
@Component({
	selector: 'app-page-layout-fullscreen',
	styles: [],
	templateUrl: './fullscreen.component.html'
})
export class PageLayoutFullscreenComponent {}
