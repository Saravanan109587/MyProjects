import { Component } from '@angular/core';

@Component({
	selector: 'app-charts',
	styles: [],
	template: `<router-outlet></router-outlet>`
})
export class ChartsComponent {}
