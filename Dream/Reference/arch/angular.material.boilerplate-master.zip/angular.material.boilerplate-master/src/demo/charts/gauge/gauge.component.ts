import { Component } from '@angular/core';

@Component({
	selector: 'app-chart-gauge',
	styles: [],
	templateUrl: './gauge.component.html'
})
export class ChartGaugeComponent {}
