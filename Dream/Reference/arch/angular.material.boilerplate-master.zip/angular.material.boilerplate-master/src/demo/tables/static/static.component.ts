import { Component } from '@angular/core';

@Component({
	selector: 'app-table-static',
	styles: [],
	templateUrl: './static.component.html'
})
export class TableStaticComponent {}
