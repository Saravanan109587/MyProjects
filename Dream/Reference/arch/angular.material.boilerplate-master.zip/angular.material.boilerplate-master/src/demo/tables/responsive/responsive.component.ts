import { Component } from '@angular/core';

@Component({
	selector: 'app-table-responsive',
	styles: [],
	templateUrl: './responsive.component.html'
})
export class TableResponsiveComponent {}
