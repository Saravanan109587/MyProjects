import { Component } from '@angular/core';

@Component({
	selector: 'app-page-sign-up',
	styles: [],
	templateUrl: './sign-up.component.html'
})
export class PageSignUpComponent {}
