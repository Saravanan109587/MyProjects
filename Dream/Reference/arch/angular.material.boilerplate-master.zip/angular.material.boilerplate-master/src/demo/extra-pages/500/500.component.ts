import { Component } from '@angular/core';

@Component({
	selector: 'app-page-500',
	styles: [],
	templateUrl: './500.component.html'
})
export class Page500Component {}
