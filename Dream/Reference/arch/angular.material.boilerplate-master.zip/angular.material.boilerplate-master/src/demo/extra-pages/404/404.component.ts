import { Component } from '@angular/core';

@Component({
	selector: 'app-page-404',
	styles: [],
	templateUrl: './404.component.html'
})
export class Page404Component {}
