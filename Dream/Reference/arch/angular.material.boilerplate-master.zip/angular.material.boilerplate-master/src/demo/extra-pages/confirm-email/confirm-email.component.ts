import { Component } from '@angular/core';

@Component({
	selector: 'app-page-confirm-email',
	styles: [],
	templateUrl: './confirm-email.component.html'
})
export class PageConfirmEmailComponent {}
