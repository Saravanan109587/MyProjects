import { Component } from '@angular/core';

@Component({
	selector: 'app-page-forgot-password',
	styles: [],
	templateUrl: './forgot-password.component.html'
})
export class PageForgotPasswordComponent {}
