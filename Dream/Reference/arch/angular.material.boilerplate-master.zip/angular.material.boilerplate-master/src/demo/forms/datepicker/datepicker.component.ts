import { Component } from '@angular/core';

@Component({
	selector: 'app-form-datepicker',
	styles: [],
	templateUrl: './datepicker.component.html'
})
export class FormDatepickerComponent {}
