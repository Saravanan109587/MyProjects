import { Component } from '@angular/core';

@Component({
	selector: 'app-form-components',
	styles: [],
	templateUrl: './components.component.html'
})
export class FormComponentsComponent {}
