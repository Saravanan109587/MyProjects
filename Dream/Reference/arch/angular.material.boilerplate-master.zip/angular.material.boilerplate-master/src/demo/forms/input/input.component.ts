import { Component } from '@angular/core';

@Component({
	selector: 'app-form-input',
	styles: [],
	templateUrl: './input.component.html'
})
export class FormInputComponent {}
