import { Component } from '@angular/core';

@Component({
	selector: 'app-form-slide-toggle',
	styles: [],
	templateUrl: './slide-toggle.component.html'
})
export class FormSlideToggleComponent {}
