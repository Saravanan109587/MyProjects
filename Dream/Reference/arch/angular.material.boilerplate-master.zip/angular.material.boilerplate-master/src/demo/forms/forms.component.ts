import { Component } from '@angular/core';

@Component({
	selector: 'app-forms',
	styles: [],
	template: `<router-outlet></router-outlet>`
})
export class FormsComponent {}
