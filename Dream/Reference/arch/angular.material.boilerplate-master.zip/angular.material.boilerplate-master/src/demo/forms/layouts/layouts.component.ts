import { Component } from '@angular/core';

@Component({
	selector: 'app-form-layouts',
	styles: [],
	templateUrl: './layouts.component.html'
})
export class FormLayoutsComponent {}
