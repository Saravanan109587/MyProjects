import { Component } from '@angular/core';

@Component({
	selector: 'app-form-checkbox',
	styles: [],
	templateUrl: './checkbox.component.html'
})
export class FormCheckboxComponent {}
