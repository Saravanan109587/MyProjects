import { Component } from '@angular/core';

@Component({
	selector: 'app-ecommerce',
	styles: [],
	template: `<router-outlet></router-outlet>`
})
export class ECommerceComponent {}
