﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NgChatSignalR.Models
{
    public class ParticipantMetadataViewModel
    {
        public int TotalUnreadMessages { get; set; }
    }
}
