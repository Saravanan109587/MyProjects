﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NgChatSignalR.Models
{
    public enum ChatParticipantTypeEnum
    {
        User = 0,
        Group = 1
    }
}
