export enum MessageType
{
    Text = 1,
    File = 2
}
