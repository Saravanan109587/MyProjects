export enum ChatParticipantStatus
{
    Online,
    Busy,
    Away,
    Offline
}
