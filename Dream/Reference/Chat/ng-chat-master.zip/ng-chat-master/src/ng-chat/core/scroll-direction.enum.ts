export enum ScrollDirection {
    Top,
    Bottom
}