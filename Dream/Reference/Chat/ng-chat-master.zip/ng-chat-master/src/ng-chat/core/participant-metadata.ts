export class ParticipantMetadata
{
    public totalUnreadMessages: number = 0;
}
