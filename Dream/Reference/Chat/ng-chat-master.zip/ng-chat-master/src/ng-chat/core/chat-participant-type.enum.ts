export enum ChatParticipantType
{
    User,
    Group
}
