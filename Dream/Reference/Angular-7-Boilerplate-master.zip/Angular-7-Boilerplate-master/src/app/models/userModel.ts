export class UserModel {
    userId: Number
    id: Number
    title: String
    completed: Boolean
}